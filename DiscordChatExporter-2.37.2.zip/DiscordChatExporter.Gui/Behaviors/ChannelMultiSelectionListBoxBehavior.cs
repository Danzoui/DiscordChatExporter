﻿using DiscordChatExporter.Core.Discord.Data;

namespace DiscordChatExporter.Gui.Behaviors;

public class ChannelMultiSelectionListBoxBehavior : MultiSelectionListBoxBehavior<Channel>
{
}