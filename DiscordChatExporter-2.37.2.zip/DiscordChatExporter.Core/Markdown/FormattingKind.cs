﻿namespace DiscordChatExporter.Core.Markdown;

internal enum FormattingKind
{
    Bold,
    Italic,
    Underline,
    Strikethrough,
    Spoiler,
    Quote
}