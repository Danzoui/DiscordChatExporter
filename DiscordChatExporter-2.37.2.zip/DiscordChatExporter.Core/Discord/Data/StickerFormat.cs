﻿namespace DiscordChatExporter.Core.Discord.Data;

public enum StickerFormat
{
    Png = 1,
    PngAnimated = 2,
    Lottie = 3
}